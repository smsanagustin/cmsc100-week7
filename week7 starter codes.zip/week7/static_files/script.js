// script.js

 